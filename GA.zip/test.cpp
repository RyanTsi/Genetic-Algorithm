#include <bits/stdc++.h>

int main () {
    std::cout << std::exp(100) << '\n';
    std::cout << std::exp(99) << '\n';
}