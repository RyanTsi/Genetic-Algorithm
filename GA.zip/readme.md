一份简单的代码实现GA （Genetic Algorithm）遗传算法。
